

        var a;
        const prompt = require('prompt-sync')();
        a = prompt('Enter a value:');
        console.log(a)

  